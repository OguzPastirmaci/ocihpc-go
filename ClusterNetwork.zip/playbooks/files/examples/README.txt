# Slurm example

module load intel_mpi
mpicc hello.c 
sbatch hello.slurm
